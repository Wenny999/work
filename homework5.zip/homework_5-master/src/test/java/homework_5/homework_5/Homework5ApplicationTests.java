package homework_5.homework_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homework5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
